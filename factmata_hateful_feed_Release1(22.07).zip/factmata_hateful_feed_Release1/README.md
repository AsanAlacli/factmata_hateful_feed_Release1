# Hateful_Feed_Release1

# Table of content 
- [Hateful_Feed_Release1](#headers)
- [Structure](#header1)
- [Features](#header2)


<br>
<br>

<a name="headers"/>

# Hateful_Feed_Release1

Hateful_Feed_Release1 aims to analyze news tweets regarding the presented features. Based on this analysis, users could see the provided labels result.


<a name="header1"/>

# Structure

The Hateful_Feed_Release1 has the following structure:

  + single index.html page (easy to read and follow)
  + linechart.js, shows the Confidence level of the algorithm
  + feed.js, connect FE and BE and send user feedback to BE
<br>
<br>

<a name="header2"/>

# Features

+ Built with [Bootstrap 4][bootstrap-home] for the responsiveness
+ Indefinite scroll, user can read all tweets in DB
+ User can send feedback by using Agree with AI or  Disagree with AI buttons
+ User can visit related. tweet by clicking the twitter image







[bootstrap-home]: https://getbootstrap.com
